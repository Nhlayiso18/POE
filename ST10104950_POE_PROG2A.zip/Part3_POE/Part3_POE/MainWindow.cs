﻿using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;

namespace Part3_POE
{
    public partial class MainWindow : Window
    {
        private ObservableCollection<Recipe> recipes;
        private ObservableCollection<Recipe> filteredRecipes;

        public MainWindow(System.Collections.IEnumerable filteredRecipes)
        {
            InitializeComponent();
            recipes = new ObservableCollection<Recipe>();
            RecipeList.ItemsSource = filteredRecipes;
            this.filteredRecipes = filteredRecipes as ObservableCollection<Recipe>;
        }

        private void Scale_Button_Click(object sender, RoutedEventArgs e)
        {
            if (RecipeList.SelectedItem is Recipe selectedRecipe)
            {
                Button scaleButton = (Button)sender;
                double scale = Convert.ToDouble(scaleButton.Content);

                selectedRecipe.ScaleIngredients(scale);
                DisplayRecipe(selectedRecipe);
            }
        }

        private void Reset_Button_Click(object sender, RoutedEventArgs e)
        {
            Recipe selectedRecipe = RecipeList.SelectedItem as Recipe;
            if (selectedRecipe != null)
            {
                selectedRecipe.ResetIngredients();
                DisplayRecipe(selectedRecipe);
            }
        }

        private void DisplayRecipe(Recipe selectedRecipe)
        {
            throw new NotImplementedException();
        }

        private void Clear_Button_Click(object sender, RoutedEventArgs e)
        {
            Recipe selectedRecipe = RecipeList.SelectedItem as Recipe;
            if (selectedRecipe != null)
            {
                recipes.Remove(selectedRecipe);
                ClearRecipe();
            }
        }

        private void AddRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            RecipeInputDialog dialog = new RecipeInputDialog();
            if (dialog.ShowDialog() == true)
            {
                Recipe recipe = dialog.Recipe;
                recipes.Add(recipe);
                UpdateFilterRecipes();
            }
        }

        private void RecipeList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Recipe selectedRecipe = RecipeList.SelectedItem as Recipe;
            if (selectedRecipe != null)
            {
                DisplayRecipe(selectedRecipe);
            }
        }

        private void ClearAllButton_Click(object sender, RoutedEventArgs e)
        {
            recipes.Clear();
            ClearRecipe();
        }

        private void ClearRecipe()
        {
            throw new NotImplementedException();
        }

        private void UpdateFilterRecipes()
        {
        }
    }
            // Implement the logic to update the filtered recipes collection based on filters.
            // For example, you can iterate through the recipes collection and filter recipes based on user
