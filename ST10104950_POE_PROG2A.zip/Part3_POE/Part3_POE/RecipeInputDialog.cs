﻿using System;

namespace Part3_POE
{
    internal class RecipeInputDialog
    {
        public Recipe Recipe { get; internal set; }

        internal bool ShowDialog()
        {
            throw new NotImplementedException();
        }
    }
}