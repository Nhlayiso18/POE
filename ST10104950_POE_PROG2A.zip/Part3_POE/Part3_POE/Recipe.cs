﻿using System;

namespace Part3_POE
{
    internal class Recipe
    {
        internal void ResetIngredients()
        {
            throw new NotImplementedException();
        }

        internal void ScaleIngredients(double scale)
        {
            throw new NotImplementedException();
        }
    }
}