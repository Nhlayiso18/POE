----My Recipe Application-----

This an application that deals with making you create your recipe.

The user will be required to follow particular steps to reach the end of the program.
The user will enter the details needed for the program to reach its final stage.
They will be required to follow instructions such as enter the number of ingredients required, the names of those ingredients,
the quantity and the unit of measurement.
After having to enter those details they will start in creating during that step they will enter the number of steps
together with the descriptions of the steps.
After having to describe the recipe will be displayed but the application will not end there.
The user will have to scale their recipe according to the options provided or clear recipe or end the program

for the second part the user will be required to add more recipes
The user will be required enter the names of the recipes
The user will choose the recipe they want to display
For ech ingredient they enter they will enter the number of calories and food group
The software will then calculate then diplay the total calories tneh notify
the user if the total number of calories exceeded 300 

from improving the 2 parts i created a Wpf application that perfomes the above functions with designs